name    = 'Cocos'
files   = {'cocos'}
configs = {
    {
        key    = 'Lua.runtime.version',
        action = 'set',
        value  = 'LuaJIT',
    },
}
