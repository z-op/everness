---@meta

---@class cc.Grid3DAction :cc.GridAction
local Grid3DAction={ }
cc.Grid3DAction=Grid3DAction




---* brief Get the effect grid rect.<br>
---* return Return the effect grid rect.
---@return rect_table
function Grid3DAction:getGridRect () end
---* 
---@return self
function Grid3DAction:clone () end
---* 
---@return cc.GridBase
function Grid3DAction:getGrid () end